﻿using Microsoft.AspNetCore.Mvc;

namespace Practica.Controllers
{
    public class MarcasController : Controller
    {
        public IActionResult Index()
        {
            
            return View();
        }
    }
}
